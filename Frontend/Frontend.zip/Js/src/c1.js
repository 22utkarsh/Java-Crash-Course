var a = 10;
console.log(a);
a = 35;
console.log(a);
function add(x, y) {
    return x + y;
}
console.log(add(4, 6));
