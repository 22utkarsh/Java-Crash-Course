let a:Number = 10;
console.log(a);
a=35;
console.log(a)
function add(x:number , y:number) :number{
    return x+y;
}
console.log(add(4,6));