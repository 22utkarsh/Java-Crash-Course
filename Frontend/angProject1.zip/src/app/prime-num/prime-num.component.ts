import { Component, OnInit } from '@angular/core';
import { PrimeService } from '../prime.service';

@Component({
  selector: 'app-prime-num',
  templateUrl: './prime-num.component.html',
  styleUrls: ['./prime-num.component.css'],
  providers:[PrimeService]
})
export class PrimeNumComponent implements OnInit {
  obj:PrimeService;
  num:string;
  flag:boolean;

  constructor(obj:PrimeService) {
    this.obj=obj;
   }

  ngOnInit(): void {
  }
  check(){
    this.flag = this.obj.checkPrime(this.num);
    console.log(this.flag);
  }

}
