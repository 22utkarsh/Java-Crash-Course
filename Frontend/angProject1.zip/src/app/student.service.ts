import { Injectable } from '@angular/core';
import { Student } from './student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  arr:Student[] = [];
  constructor() { }

  add(obj:Student){
    this.arr.push(obj);
  }

  getStudent():Student[]{
    return this.arr;
  }
}
