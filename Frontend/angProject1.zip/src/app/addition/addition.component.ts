import { Component, OnInit } from '@angular/core';
import { NgModel , FormsModule } from '@angular/forms';


@Component({
  selector: 'app-addition',
  templateUrl: './addition.component.html',
  styleUrls: ['./addition.component.css']
})
export class AdditionComponent implements OnInit {
  num1:string="";
  num2:string="";
  num3:number=0;
  num:number=0;
  arr:number[]=[1,2,3,4,5,6,7,8,9,10];

  addition(){
    this.num3=parseInt(this.num1)+parseInt(this.num2);
  }

  ngOnInit(): void {
  }

}
