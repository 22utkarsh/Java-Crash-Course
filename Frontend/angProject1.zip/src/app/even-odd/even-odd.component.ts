import { Component, OnInit } from '@angular/core';
import { NumbercheckService } from '../numbercheck.service';

@Component({
  selector: 'app-even-odd',
  templateUrl: './even-odd.component.html',
  styleUrls: ['./even-odd.component.css'],
  providers:[NumbercheckService]
})
export class EvenOddComponent implements OnInit {
  obj:NumbercheckService;
  flag:boolean;
  num:string;
  constructor(obj:NumbercheckService) { 
    this.obj=obj;
  }

  even() {
    this.flag=this.obj.checkEven(this.num);
  }

  ngOnInit(): void {
  }

}
