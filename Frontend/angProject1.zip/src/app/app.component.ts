import { Component } from '@angular/core';
import { NumbercheckService } from "./numbercheck.service";
import { StudentApiService } from './student-api.service';
import { StudentService } from './student.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[NumbercheckService,StudentService,StudentApiService]
})
export class AppComponent {
  title = 'angProject1';
}
