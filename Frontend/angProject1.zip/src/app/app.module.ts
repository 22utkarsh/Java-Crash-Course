import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule,FormGroup ,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdditionComponent } from './addition/addition.component';
import { EvenOddComponent } from './even-odd/even-odd.component';
import { PrimeNumComponent } from './prime-num/prime-num.component';
import { StudentFormComponent } from './student-form/student-form.component';
import { Student1Component } from './student1/student1.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    AdditionComponent,
    EvenOddComponent,
    PrimeNumComponent,
    StudentFormComponent,
    Student1Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
