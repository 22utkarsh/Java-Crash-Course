import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
import { Student1 } from './student1';
@Injectable({
  providedIn: 'root'
})
export class StudentApiService {
  BaseUrl: string = "http://localhost:8071/test";
  http:HttpClient;
  constructor(http:HttpClient) { 
    this.http=http;
  }

  getAllStudents():Observable<Student1[]>{
    return this.http.get<Student1[]>(`${this.BaseUrl}/student`);
  }

}
