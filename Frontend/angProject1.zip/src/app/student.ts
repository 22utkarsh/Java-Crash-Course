export class Student {
    name:string;
    age:string;
    city:string;
}
