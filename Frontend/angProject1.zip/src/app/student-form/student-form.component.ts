import { Component, OnInit } from '@angular/core';
import {AbstractControl, FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { StudentService } from '../student.service';
import { Student } from '../student';

@Component({
  selector: 'app-student-form',
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.css'],
  providers:[StudentService]
})
export class StudentFormComponent implements OnInit {
  form: FormGroup;
  submitted = false;
  obj:StudentService;
  studObj:Student[];
  show:boolean=false;
  stud1:Student ;
  constructor(private  formBuilder:FormBuilder , studServ:StudentService) { 
    this.obj=studServ;
  }


  ngOnInit(): void {
    this.form = this.formBuilder.group(
        {
          name: ['', 
          [
            Validators.required,
            Validators.minLength(2),
            Validators.pattern("[a-zA-Z ]*")
          ]
        ],
          age: [ '',
            [
                Validators.required,
                Validators.minLength(2)
            ]
          ],
          city: [ '',
            [
                Validators.required,
                Validators.minLength(2)
            ]
          ]
        }
    );
   
  }

  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }

  onSubmit(): void {
    this.submitted = true;

    if (this.form.invalid) {
      return;
    }

    this.stud1 = new Student();
    this.stud1.name=this.form.value['name'];
    this.stud1.age=this.form.value['age'];
    this.stud1.city=this.form.value['city'];

    console.log(this.stud1);

    this.obj.add(this.stud1);

    // console.log(JSON.stringify(this.form.value, null, 2));

  }


  getList(){
    this.studObj=this.obj.getStudent();
    this.show=true;
    console.log(this.studObj)
  }




  onReset(): void {
    this.submitted = false;
    this.form.reset();
  }

 

}
