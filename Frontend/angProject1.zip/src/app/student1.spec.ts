import { Student1 } from './student1';

describe('Student1', () => {
  it('should create an instance', () => {
    expect(new Student1()).toBeTruthy();
  });
});
