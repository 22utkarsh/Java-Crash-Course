import { Component, OnInit } from '@angular/core';
import { StudentApiService } from '../student-api.service';
import { Student1 } from '../student1';

@Component({
  selector: 'app-student1',
  templateUrl: './student1.component.html',
  styleUrls: ['./student1.component.css'],
  providers:[StudentApiService]
})
export class Student1Component implements OnInit {
  studServ:StudentApiService
  studentList:Student1[];
  constructor(studServ:StudentApiService) { 
    this.studServ=studServ;
  }

  ngOnInit(): void {
  }

  readData(){
    this.studServ.getAllStudents().subscribe(data=>{
      this.studentList=data;
    });
  }

}
