import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PrimeService {

  constructor() { }

  checkPrime(a:string):boolean{
    for (let i = 2; i < parseInt(a); i++) {
      if((parseInt(a)%i)===0){
        return false;
      }
    }
    return true;
  }
}
