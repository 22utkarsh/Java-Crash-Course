import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NumbercheckService {

  constructor() { }

  checkEven(a:string ):boolean{
    if(Number.parseInt(a)%2===0){
      return true;
    }else{
      return false;
    }
  }

}
