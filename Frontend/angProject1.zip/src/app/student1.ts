export class Student1 {
    student_id:number;
    fname:string;
    lname:string;
}
