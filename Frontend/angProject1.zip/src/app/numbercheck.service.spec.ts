import { TestBed } from '@angular/core/testing';

import { NumbercheckService } from './numbercheck.service';

describe('NumbercheckService', () => {
  let service: NumbercheckService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NumbercheckService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
