package com.rummy;

public class Demo {
	public static void main(String[] args) {
		Rummy2 p1 = new Rummy2("Player1");
		Rummy2 p2 = new Rummy2("Player2");
		Rummy2 p3 = new Rummy2("Player3");
		
		p1.start();
		p2.start();
		p3.start();
		
		
	}
	
	
}
