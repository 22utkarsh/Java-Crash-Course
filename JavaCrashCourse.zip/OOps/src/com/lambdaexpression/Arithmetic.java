package com.lambdaexpression;

public interface Arithmetic {
	
	public int calculate(int a,int b);

}
