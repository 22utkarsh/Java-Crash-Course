package com.Inheritence;

public class Substract extends Arithmetic {
	
	public Substract() {
		super();
	}
	
	public Substract(int a, int b) {
		super(a,b);
		
	}
	
	public int calculate() {
		return (super.sub());
	}
}
