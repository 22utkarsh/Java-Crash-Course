package com.Inheritence;

public class Multiply extends Arithmetic{
	
	public Multiply() {
		super();
	}
	public Multiply(int a, int b) {
		super(a,b);
	
	}
	
	public int calculate() {
		return (super.multiply());
	}

}
 