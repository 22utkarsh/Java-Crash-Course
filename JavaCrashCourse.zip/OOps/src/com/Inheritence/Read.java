package com.Inheritence;

import java.util.Scanner;

public class Read {
	static Scanner sc = new Scanner(System.in);
		
}