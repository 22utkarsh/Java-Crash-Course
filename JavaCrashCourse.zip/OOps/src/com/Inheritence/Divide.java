package com.Inheritence;

public class Divide extends Arithmetic {
	
	public Divide() {
		super();
	}
	public Divide(int a, int b) {
		super(a,b);
	
	}
	
	public int calculate() {
		return (super.divide());
	}

}
