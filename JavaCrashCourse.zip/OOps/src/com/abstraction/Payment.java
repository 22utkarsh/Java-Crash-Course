package com.abstraction;

// Interface we hide the method implementation and showing only necessary information
public interface Payment {
	
	public String doPayment(long ac , int amount);

}
