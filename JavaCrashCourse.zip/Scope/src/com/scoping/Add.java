package com.scoping;

public class Add {
	int n1;
	int n2;
	static int n3;
	public Add() {
		System.out.println("I am in No argument Constructor !");
	}
	public void finalize() {
		System.out.println("I am in no argument Destructor");
	}
	
}
