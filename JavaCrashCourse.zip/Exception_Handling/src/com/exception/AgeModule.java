package com.exception;

public class AgeModule extends Exception{
	public AgeModule() {
		super("Your age is not suit for this!!");
	}
}
