package com.reader;

import java.util.Scanner;

public class Read {
	public static Scanner sc = new Scanner(System.in);
}
